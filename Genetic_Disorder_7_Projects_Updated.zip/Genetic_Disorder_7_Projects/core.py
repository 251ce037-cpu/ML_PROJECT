import json, warnings
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectPercentile, f_classif
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, confusion_matrix, silhouette_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from scipy.cluster.hierarchy import linkage, dendrogram
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import joblib
from config import DATA_DIR, OUTPUT, MODELS

TARGETS=['Genetic Disorder','Disorder Subclass']
EXCLUDE=['Patient Id','Patient ID','Patient First Name','Family Name','Father\'s name','Mother\'s name','Institute Name','Location of Institute','Place of birth','Test 1','Test 2','Test 3','Test 4','Test 5']

def load_data(path=None):
    if path is None:
        files=list(DATA_DIR.glob('*.csv'))
        if not files: raise FileNotFoundError('Place Kaggle train.csv in data/ (see README).')
        path=next((p for p in files if 'train' in p.name.lower()),files[0])
    df=pd.read_csv(path,low_memory=False)
    df.columns=df.columns.str.strip()
    df=df.replace(r'^\s*$',np.nan,regex=True).replace(['-','--','?','Unknown','unknown','Not available','not available'],np.nan)
    return df.drop_duplicates().reset_index(drop=True)

def prepare(df,target=None):
    d=df.copy()
    if target:
        if target not in d: raise ValueError(f'Missing target {target}. Columns: {list(d.columns)}')
        d=d[d[target].notna()].copy()
    excluded=set(EXCLUDE+TARGETS)
    columns=[c for c in d.columns if c not in excluded and not c.lower().startswith('unnamed')]
    X=d[columns].copy()
    for c in X:
        if X[c].dtype=='object':
            asnum=pd.to_numeric(X[c],errors='coerce')
            if asnum.notna().sum()>0 and asnum.notna().sum()>=.95*X[c].notna().sum(): X[c]=asnum
    # Remove high-cardinality free text and all-null columns; avoid unique identifiers leaking into the model.
    columns=[c for c in X if X[c].notna().any() and not (X[c].dtype=='object' and X[c].nunique(dropna=True)>max(40,.5*len(X)))]
    X=X[columns]
    if X.shape[1]==0: raise ValueError('No usable predictor columns.')
    return X,(d[target].astype(str) if target else None)

def preprocessor(X):
    num=X.select_dtypes(include='number').columns.tolist(); cat=[c for c in X if c not in num]
    transforms=[]
    if num: transforms.append(('num',Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num))
    if cat: transforms.append(('cat',Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('encode',OneHotEncoder(handle_unknown='ignore',sparse_output=False,min_frequency=2))]),cat))
    return ColumnTransformer(transforms,remainder='drop',sparse_threshold=0)

def save_json(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,default=lambda o:float(o) if isinstance(o,np.floating) else int(o) if isinstance(o,np.integer) else str(o)))

def evaluation(y,yp,classes):
    p,r,f,_=precision_recall_fscore_support(y,yp,average='macro',zero_division=0)
    return {'accuracy':accuracy_score(y,yp),'precision_macro':p,'recall_macro':r,'f1_macro':f,'report':classification_report(y,yp,labels=classes,output_dict=True,zero_division=0),'confusion_matrix':confusion_matrix(y,yp,labels=classes).tolist(),'labels':list(map(str,classes))}

def save_cm(result,pid):
    fig,ax=plt.subplots(figsize=(max(6,len(result['labels'])*1.4),5))
    cm=np.array(result['confusion_matrix']); ax.imshow(cm,cmap='Blues')
    ax.set_xticks(range(len(cm)),result['labels'],rotation=40,ha='right');ax.set_yticks(range(len(cm)),result['labels'])
    for i in range(len(cm)):
        for j in range(len(cm)):ax.text(j,i,str(cm[i,j]),ha='center',va='center')
    ax.set(xlabel='Predicted',ylabel='Actual',title='Confusion Matrix');fig.tight_layout();fig.savefig(OUTPUT/f'project_{pid}_confusion.png',dpi=140);plt.close(fig)

def train_classifier(pid,df,target):
    X,y=prepare(df,target)
    if y.nunique()<2:raise ValueError('Need at least 2 target classes')
    counts=y.value_counts(); strat=y if counts.min()>=2 and len(y)*.2>=y.nunique() else None
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=strat)
    if pid==1: models={'logistic':LogisticRegression(max_iter=1500,class_weight='balanced')}
    elif pid==2: models={k:SVC(kernel=k,probability=True,class_weight='balanced',random_state=42) for k in ['linear','poly','rbf']}
    elif pid==3: models={'tree':DecisionTreeClassifier(max_depth=6,min_samples_leaf=5,class_weight='balanced',random_state=42)}
    else:
        from xgboost import XGBClassifier
        models={'xgboost':XGBClassifier(n_estimators=120,max_depth=4,learning_rate=.07,subsample=.85,colsample_bytree=.85,random_state=42,eval_metric='mlogloss')}
    enc=LabelEncoder() if pid==4 else None
    if enc is not None:
        enc.fit(ytr); yt=enc.transform(ytr); ytest=enc.transform(yte)
    else:yt=ytr;ytest=yte
    results={}; winner=None; best=-1
    for name,est in models.items():
        steps=[('prep',preprocessor(Xtr))]
        # Feature selection is embedded in each supervised pipeline, fitted only on training folds.
        steps.extend([('select',SelectPercentile(score_func=f_classif,percentile=80)),('model',est)])
        pipe=Pipeline(steps)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore');pipe.fit(Xtr,yt)
        pred=pipe.predict(Xte)
        if enc is not None: pred=enc.inverse_transform(pred);truth=yte
        else:truth=yte
        result=evaluation(truth,pred,sorted(y.unique()))
        cv=min(5,int(ytr.value_counts().min()))
        if cv>=2:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                try: scores=cross_validate(pipe,Xtr,yt,cv=StratifiedKFold(n_splits=cv,shuffle=True,random_state=42),scoring='f1_macro',error_score=np.nan)['test_score'];result['cv_f1_macro_mean']=float(np.nanmean(scores))
                except Exception as e:result['cv_note']=str(e)
        results[name]=result
        if result['f1_macro']>best:best=result['f1_macro'];winner=(name,pipe,result)
    name,pipe,result=winner
    save_cm(result,pid)
    artifact={'pipeline':pipe,'features':X.columns.tolist(),'target':target,'label_encoder':enc,'algorithm':name,'classes':sorted(y.unique())}
    joblib.dump(artifact,MODELS/f'project_{pid}.joblib')
    save_json(OUTPUT/f'project_{pid}_metrics.json',{'selected':name,'models':results,'n_train':len(Xtr),'n_test':len(Xte),'target':target,'features':X.columns.tolist()})
    if pid==3:
        names=pipe.named_steps['prep'].get_feature_names_out();names=names[pipe.named_steps['select'].get_support()]
        imp=pd.Series(pipe.named_steps['model'].feature_importances_,index=names).sort_values(ascending=False).head(20)
        fig,ax=plt.subplots(figsize=(9,6));imp.iloc[::-1].plot.barh(ax=ax);ax.set_title('Decision Tree Feature Importance');fig.tight_layout();fig.savefig(OUTPUT/'project_3_importance.png');plt.close(fig)
        fig,ax=plt.subplots(figsize=(16,8));plot_tree(pipe.named_steps['model'],max_depth=3,feature_names=list(names),filled=True,fontsize=7,ax=ax);fig.tight_layout();fig.savefig(OUTPUT/'project_3_tree.png',dpi=130);plt.close(fig)
        result['train_accuracy']=float(pipe.score(Xtr,yt));result['test_accuracy']=float(pipe.score(Xte,ytest))
        save_json(OUTPUT/'project_3_overfit.json',{'train_accuracy':result['train_accuracy'],'test_accuracy':result['test_accuracy']})
    if pid==4:
        probabilities=pipe.predict_proba(Xte).max(axis=1)
        categories=np.where(probabilities>=.8,'High',np.where(probabilities>=.5,'Medium','Low'))
        pd.DataFrame({'patient_id':Xte.index,'predicted_category':pred,'probability':probabilities,'priority_level':categories}).to_csv(OUTPUT/'project_4_priorities.csv',index=False)
        # Priority means prediction confidence, NOT medical severity.
    return results

def cluster_projects(pid,df):
    X,_=prepare(df); X=X.sample(min(len(X),1500),random_state=42) if pid==6 else X.sample(min(len(X),5000),random_state=42)
    pre=preprocessor(X);Z=pre.fit_transform(X)
    reducer=None
    if Z.shape[1]>100:
        reducer=PCA(n_components=min(30,Z.shape[0]-1,Z.shape[1]),random_state=42)
        Z=reducer.fit_transform(Z)
    if len(X)<8:raise ValueError('At least 8 records needed for clustering')
    ks=list(range(2,min(8,len(X)-1)+1));results=[]
    for k in ks:
        if pid==5: labels=KMeans(n_clusters=k,n_init=10,random_state=42).fit_predict(Z)
        else:labels=AgglomerativeClustering(n_clusters=k,linkage='ward').fit_predict(Z)
        sil=float(silhouette_score(Z,labels,sample_size=min(1000,len(Z)),random_state=42)) if len(set(labels))>1 else -1
        inertia=float(KMeans(n_clusters=k,n_init=10,random_state=42).fit(Z).inertia_) if pid==5 else None
        results.append({'k':k,'silhouette':sil,'inertia':inertia})
    chosen=max(results,key=lambda r:r['silhouette'])['k']
    if pid==5:
        model=KMeans(n_clusters=chosen,n_init=10,random_state=42).fit(Z);labels=model.labels_
    else:model=AgglomerativeClustering(n_clusters=chosen,linkage='ward');labels=model.fit_predict(Z)
    coords=PCA(n_components=2,random_state=42).fit_transform(Z)
    fig,ax=plt.subplots(figsize=(8,6));ax.scatter(coords[:,0],coords[:,1],c=labels,cmap='tab10',s=9,alpha=.6);ax.set(title=f'Project {pid}: Patient Groups (PCA projection)',xlabel='PC1',ylabel='PC2');fig.tight_layout();fig.savefig(OUTPUT/f'project_{pid}_clusters.png');plt.close(fig)
    fig,ax=plt.subplots();ax.plot(ks,[r['silhouette'] for r in results],marker='o');ax.set(xlabel='Number of clusters',ylabel='Silhouette score');fig.tight_layout();fig.savefig(OUTPUT/f'project_{pid}_silhouette.png');plt.close(fig)
    if pid==5:
        fig,ax=plt.subplots();ax.plot(ks,[r['inertia'] for r in results],marker='o');ax.set(xlabel='Number of clusters',ylabel='Inertia',title='Elbow Method');fig.tight_layout();fig.savefig(OUTPUT/'project_5_elbow.png');plt.close(fig)
    else:
        fig,ax=plt.subplots(figsize=(11,5));dendrogram(linkage(Z[:min(150,len(Z))],method='ward'),truncate_mode='lastp',p=20,ax=ax);ax.set(title='Ward Dendrogram (up to 150 sampled rows)');fig.tight_layout();fig.savefig(OUTPUT/'project_6_dendrogram.png');plt.close(fig)
        km=KMeans(n_clusters=chosen,n_init=10,random_state=42).fit_predict(Z)
        from sklearn.metrics import adjusted_rand_score
        comparison={'kmeans_vs_ward_adjusted_rand':float(adjusted_rand_score(labels,km))}
        save_json(OUTPUT/'project_6_comparison.json',comparison)
    out=X.copy();out['cluster']=labels;out.to_csv(OUTPUT/f'project_{pid}_groups.csv',index=False)
    summaries={str(k):{'count':int((labels==k).sum()),'description':'Unsupervised group; review feature distributions before assigning a clinical interpretation.'} for k in sorted(set(labels))}
    artifact={'preprocessor':pre,'reducer':reducer,'model':model if pid==5 else None,'features':X.columns.tolist(),'algorithm':'kmeans' if pid==5 else 'ward','clusters':chosen}
    joblib.dump(artifact,MODELS/f'project_{pid}.joblib')
    save_json(OUTPUT/f'project_{pid}_metrics.json',{'selected_k':chosen,'scores':results,'group_summary':summaries,'sample_size':len(X),'note':'Clustering is exploratory, not a genetic diagnosis. Ward has no native out-of-sample predict.'})

def project7(df):
    X,y=prepare(df,'Genetic Disorder')
    X=X.sample(min(5000,len(X)),random_state=42);y=y.loc[X.index]
    prep=preprocessor(X);Z=prep.fit_transform(X)
    pca=PCA(n_components=min(2,Z.shape[1],len(Z)-1),random_state=42);xy=pca.fit_transform(Z)
    if xy.shape[1]<2:raise ValueError('Need at least two transformed features')
    le=LabelEncoder();coded=le.fit_transform(y)
    fig,ax=plt.subplots(figsize=(8,6));ax.scatter(xy[:,0],xy[:,1],c=coded,s=8,cmap='tab10',alpha=.6);ax.set(xlabel='PC1',ylabel='PC2',title='PCA: Unsupervised Projection');fig.tight_layout();fig.savefig(OUTPUT/'project_7_pca.png');plt.close(fig)
    lda_result=None;lda=None
    if len(le.classes_)>1:
        ncomp=min(2,len(le.classes_)-1,Z.shape[1]);lda=LinearDiscriminantAnalysis(n_components=ncomp)
        try:
            lda_xy=lda.fit_transform(Z,coded)
            fig,ax=plt.subplots(figsize=(8,6));ax.scatter(lda_xy[:,0],lda_xy[:,1] if ncomp>1 else np.zeros(len(X)),c=coded,s=8,cmap='tab10',alpha=.6);ax.set(xlabel='LD1',ylabel='LD2' if ncomp>1 else 'zero (only 1 LD possible)',title='LDA: Supervised Projection');fig.tight_layout();fig.savefig(OUTPUT/'project_7_lda.png');plt.close(fig)
            lda_result={'components':ncomp,'explained_variance_ratio':lda.explained_variance_ratio_.tolist()}
        except Exception as e:lda=None;lda_result={'error':str(e)}
    joblib.dump({'preprocessor':prep,'pca':pca,'lda':lda,'features':X.columns.tolist()},MODELS/'project_7.joblib')
    save_json(OUTPUT/'project_7_metrics.json',{'original_features':X.shape[1],'encoded_features':Z.shape[1],'pca_explained_variance_ratio':pca.explained_variance_ratio_.tolist(),'lda':lda_result,'sample_size':len(X),'note':'PCA is unsupervised; LDA uses known disorder labels.'})

def predict(pid,record):
    art=joblib.load(MODELS/f'project_{pid}.joblib')
    if pid==7:raise ValueError('Project 7 is a visualization project, not a classifier')
    if pid==6:raise ValueError('Ward hierarchical clustering cannot directly predict new patients; use group exploration.')
    row=pd.DataFrame([record]).reindex(columns=art['features'])
    if pid==5:
        z=art['preprocessor'].transform(row)
        if art.get('reducer') is not None: z=art['reducer'].transform(z)
        return {'cluster':int(art['model'].predict(z)[0]),'note':'Exploratory similarity group, not a diagnosis'}
    pipe=art['pipeline'];p=pipe.predict(row)[0]
    if art['label_encoder'] is not None:p=art['label_encoder'].inverse_transform([int(p)])[0]
    result={'predicted_category':str(p),'algorithm':art['algorithm'],'disclaimer':'Educational screening demonstration only; not a medical diagnosis.'}
    if hasattr(pipe,'predict_proba'):
        probs=pipe.predict_proba(row)[0];result['probability']=float(np.max(probs))
        if pid==4:result['priority_level']='High' if max(probs)>=.8 else 'Medium' if max(probs)>=.5 else 'Low';result['priority_note']='Confidence-based review priority, NOT clinical risk/severity.'
    return result
