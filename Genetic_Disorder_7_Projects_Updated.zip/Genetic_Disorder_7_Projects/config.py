from pathlib import Path
ROOT=Path(__file__).resolve().parent
DATA_DIR=ROOT/'data'
OUTPUT=ROOT/'outputs'
MODELS=ROOT/'models'
for d in (DATA_DIR,OUTPUT,MODELS): d.mkdir(exist_ok=True)
PROJECTS={1:('Genetic Disorder Risk Classification','Genetic Disorder'),2:('Genetic Disorder Subclass Screening','Disorder Subclass'),3:('Explainable Genetic Disorder Risk Assessment','Genetic Disorder'),4:('Genetic Disorder Risk Prioritization','Genetic Disorder'),5:('Patient Genetic Phenotype Segmentation',None),6:('Genetic Patient Similarity Analysis',None),7:('Genetic Data Compression and Pattern Visualization','Genetic Disorder')}
