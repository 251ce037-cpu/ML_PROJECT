import unittest
import pandas as pd
from core import prepare,preprocessor
class BasicTests(unittest.TestCase):
    def test_prepare_excludes_target_and_ids(self):
        d=pd.DataFrame({'Patient Id':[1,2,3],'Age':[10,20,30],'Genetic Disorder':['A','B','A'],'Disorder Subclass':['x','y','x']})
        x,y=prepare(d,'Genetic Disorder');self.assertEqual(list(x.columns),['Age']);self.assertEqual(len(y),3)
    def test_transform(self):
        x=pd.DataFrame({'Age':[10,None,30],'Sex':['M','F','M']})
        self.assertEqual(preprocessor(x).fit_transform(x).shape[0],3)
if __name__=='__main__':unittest.main()
