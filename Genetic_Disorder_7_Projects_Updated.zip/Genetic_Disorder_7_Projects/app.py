import json
import pandas as pd
import streamlit as st
import requests
from config import PROJECTS,OUTPUT,MODELS
from core import load_data
import joblib
st.set_page_config(page_title='Genetic Analytics Lab',layout='wide',page_icon='🧬')
st.title('🧬 Genetic Analytics Lab — Seven ML Projects')
st.warning('Educational research demonstration only. Not validated for diagnosis, medical triage or treatment.')
pid=st.sidebar.selectbox('Choose a project',list(PROJECTS),format_func=lambda i:f'{i}. {PROJECTS[i][0]}')
st.header(f'Project {pid}: {PROJECTS[pid][0]}')
path=OUTPUT/f'project_{pid}_metrics.json'
if not path.exists():
    st.error('No trained results yet. Download the Kaggle dataset and run: python train_all.py')
    st.stop()
metrics=json.loads(path.read_text())
st.subheader('Model performance / analysis')
if pid in (1,2,3,4):
    st.write('Selected algorithm:',metrics['selected'])
    for name,m in metrics['models'].items():
        with st.expander(f'{name}: Accuracy {m["accuracy"]:.3f}, Macro F1 {m["f1_macro"]:.3f}',expanded=name==metrics['selected']):
            c1,c2,c3,c4=st.columns(4)
            c1.metric('Accuracy',f'{m["accuracy"]:.3f}');c2.metric('Macro precision',f'{m["precision_macro"]:.3f}');c3.metric('Macro recall',f'{m["recall_macro"]:.3f}');c4.metric('Macro F1',f'{m["f1_macro"]:.3f}')
            if 'cv_f1_macro_mean' in m:st.write('Cross-validation macro F1:',round(m['cv_f1_macro_mean'],3))
            st.dataframe(pd.DataFrame(m['report']).T)
else:st.json(metrics)
for img in sorted(OUTPUT.glob(f'project_{pid}_*.png')):
    st.subheader(img.stem.replace('_',' ').title());st.image(str(img),use_container_width=True)
for csv in sorted(OUTPUT.glob(f'project_{pid}_*.csv')):
    st.subheader(csv.stem.replace('_',' ').title());st.dataframe(pd.read_csv(csv).head(1000));st.download_button('Download '+csv.name,csv.read_bytes(),csv.name)
if pid in (1,2,3,4,5):
    st.subheader('Patient input and prediction')
    artifact=joblib.load(MODELS/f'project_{pid}.joblib')
    try:df=load_data()
    except FileNotFoundError:df=pd.DataFrame()
    with st.form('patient'):
        record={}
        for feature in artifact['features']:
            if feature in df.columns:
                s=df[feature].dropna()
                if pd.api.types.is_numeric_dtype(df[feature]):
                    record[feature]=st.number_input(feature,value=float(s.median()) if len(s) else 0.0)
                else:
                    options=sorted(s.astype(str).unique().tolist())
                    record[feature]=st.selectbox(feature,options) if options else st.text_input(feature)
            else:record[feature]=st.text_input(feature)
        submitted=st.form_submit_button('Predict')
    if submitted:
        try:
            response=requests.post('http://127.0.0.1:5000/predict/'+str(pid),json=record,timeout=30)
            if response.ok:st.success('Result');st.json(response.json())
            else:st.error(response.text)
        except requests.RequestException:st.error('Start Flask API first: python api.py')
elif pid==6:st.info('Ward hierarchical clustering groups existing records; it does not directly classify a new record.')
else:st.info('PCA and LDA are visual analytics techniques. Explore the saved plots above.')
