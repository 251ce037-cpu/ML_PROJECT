import argparse,traceback
from config import PROJECTS,OUTPUT
from core import load_data,train_classifier,cluster_projects,project7,save_json

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data',default=None);args=parser.parse_args()
    df=load_data(args.data)
    print('Dataset loaded:',df.shape)
    errors={}
    for pid,(name,target) in PROJECTS.items():
        print(f'Project {pid}: {name}')
        try:
            if pid in (1,2,3,4):train_classifier(pid,df,target)
            elif pid in (5,6):cluster_projects(pid,df)
            else:project7(df)
            print('  completed')
        except Exception as e:
            errors[str(pid)]=str(e);print('  FAILED:',e);traceback.print_exc()
    save_json(OUTPUT/'training_status.json',{'errors':errors,'completed':[i for i in range(1,8) if str(i) not in errors]})
    if errors:raise SystemExit('Some projects failed; check outputs/training_status.json')
if __name__=='__main__':main()
