# Genetic Analytics Lab — Batch 1 (7 Projects)

## What is included
Seven projects matching the supplied business-problem PDF:
1. Logistic Regression: disorder classification
2. SVM: subclass classification, linear/poly/RBF comparison
3. Decision Tree: explainable classification, feature importance and overfitting check
4. XGBoost: classification and confidence-based review priority
5. K-Means: patient segmentation, elbow and silhouette plots
6. Ward Hierarchical Clustering: dendrogram, cluster-count comparison, K-Means comparison
7. PCA + LDA: explained variance and dimensionality-reduction visualizations

## Important: required original dataset
The uploaded PDF provided a Kaggle link, **not the dataset CSV**. Download the original dataset from:
https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data

Place **train.csv** inside `data/` (or run `python train_all.py --data /path/to/train.csv`). Do not substitute fabricated patient data. The included archive contains complete implementation but **does not include pretrained models or verified scores** until the real data is provided and training completes. Kaggle's terms and dataset license govern reuse.

## Setup (Python 3.10–3.12 recommended)
```
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python train_all.py
```
Training creates serialized artifacts in `models/`, metrics/figures/tables in `outputs/`.

## Run backend and frontend (two terminals)
```
python api.py
```
In another terminal:
```
streamlit run app.py
```
Open the local URL shown by Streamlit (usually http://localhost:8501).

## API examples
`GET http://127.0.0.1:5000/health`
`GET http://127.0.0.1:5000/metrics/1`
`POST http://127.0.0.1:5000/predict/1` with JSON object containing model input columns.

## Important methodological notes
- Train/test split 80/20, stratified when feasible. Feature preprocessing/selection inside pipelines prevents leakage across folds.
- Macro F1 and class-wise recall matter because minority classes may be missed despite high accuracy. Review the class-wise confusion matrix and recall; false negatives are especially concerning for screening, but the project is not clinically validated.
- Project 4's High/Medium/Low categories are **model confidence bands**, not medical severity or true genetic disease risk. These thresholds are illustrative, not clinically justified.
- Clusters are exploratory and cannot be interpreted as diagnoses. Ward clustering cannot natively predict for new records.
- Dataset may contain missing labels; only rows with known target labels are used for supervised learning.
- Model comparisons on a single test split are illustrative; for formal model selection, tune on cross-validation and reserve a final untouched test set.
- Never enter real identifiable patient records into this educational demo.

## Folder guide
- `core.py`: shared preprocessing, algorithms, evaluations, plots, serialization
- `train_all.py`: execute all seven projects
- `api.py`: Flask endpoints
- `app.py`: Streamlit interface
- `config.py`: project metadata and paths
- `data/`: place original Kaggle CSV here
- `models/`: trained artifacts (generated)
- `outputs/`: actual metrics, charts, tables (generated)
- `reports/`: project summaries and critical thinking answers
- `tests/`: basic tests

## Submission checklist
1. Download original CSV and place it in `data/`.
2. Install dependencies and run training; check `outputs/training_status.json` for any errors.
3. Run Flask + Streamlit, confirm charts and sample predictions.
4. Add your own student/institution details and screenshots if required by faculty.
5. Zip the final folder and upload to Google Classroom.


## Submission verification (important)
This package does **not** include the Kaggle training CSV or any trained model artifacts.
The source dataset must be downloaded by the student from the Kaggle link in the assignment and placed at `data/train.csv`.
Run `pip install -r requirements.txt`, then `python train_all.py`, then `python -m unittest discover -s tests`.
Review `outputs/training_status.json` and generated charts/metrics before claiming completed experiments.
**Do not report model accuracy or experimental findings before training on the actual dataset.**
This is educational software and must not be used for clinical decisions.
