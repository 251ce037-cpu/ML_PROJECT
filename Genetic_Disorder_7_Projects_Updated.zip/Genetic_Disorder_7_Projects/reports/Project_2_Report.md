# Project 2: Genetic Disorder Subclass Screening

## Business objective
Build an educational analytics system on the supplied Kaggle genetic-disorder dataset, using **SVM (Linear, Polynomial, RBF)**.

## Data source
Kaggle: https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data
The dataset was not attached. Data-dependent observations and numerical results must be populated only after actual training.

## Methodology
1. Load original CSV and inspect columns and missingness.
2. Remove identifiers and target leakage; impute missing values; encode categoricals; scale numeric columns.
3. Apply the primary algorithm: **SVM (Linear, Polynomial, RBF)**.
4. Review outputs from `python train_all.py` in `outputs/project_2_metrics.json` and corresponding charts.
5. Interpret outcomes with appropriate caution and limitations.

## Critical thinking answer
Kernel functions produce different boundaries: linear models straight separations; polynomial models feature interactions; RBF models nonlinear local boundaries. Select using validation macro F1 and per-class recall, not an assumed winner.

## Results
**Pending actual dataset and execution.** Do not report fictional accuracy, confusion matrices or silhouette values. After training, insert real metrics, charts and screenshots here.

## Limitations and ethics
This is an educational prototype, not a clinically validated system. Do not use it to diagnose patients, infer severity or make healthcare decisions. Avoid uploading identifiable patient data.

## Conclusion
The implementation provides a reproducible baseline and interactive visualizations. Findings must be checked against actual experimental outputs before submission.
