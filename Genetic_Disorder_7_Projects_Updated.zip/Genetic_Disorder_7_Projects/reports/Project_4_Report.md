# Project 4: Genetic Disorder Risk Prioritization

## Business objective
Build an educational analytics system on the supplied Kaggle genetic-disorder dataset, using **XGBoost**.

## Data source
Kaggle: https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data
The dataset was not attached. Data-dependent observations and numerical results must be populated only after actual training.

## Methodology
1. Load original CSV and inspect columns and missingness.
2. Remove identifiers and target leakage; impute missing values; encode categoricals; scale numeric columns.
3. Apply the primary algorithm: **XGBoost**.
4. Review outputs from `python train_all.py` in `outputs/project_4_metrics.json` and corresponding charts.
5. Interpret outcomes with appropriate caution and limitations.

## Critical thinking answer
A 0.50 threshold is not universally appropriate in multiclass settings. Examine precision-recall trade-offs across confidence thresholds; model confidence must not be confused with medical risk.

## Results
**Pending actual dataset and execution.** Do not report fictional accuracy, confusion matrices or silhouette values. After training, insert real metrics, charts and screenshots here.

## Limitations and ethics
This is an educational prototype, not a clinically validated system. Do not use it to diagnose patients, infer severity or make healthcare decisions. Avoid uploading identifiable patient data.

## Conclusion
The implementation provides a reproducible baseline and interactive visualizations. Findings must be checked against actual experimental outputs before submission.
