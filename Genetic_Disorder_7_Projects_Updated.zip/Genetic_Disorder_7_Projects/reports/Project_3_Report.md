# Project 3: Explainable Genetic Disorder Risk Assessment

## Business objective
Build an educational analytics system on the supplied Kaggle genetic-disorder dataset, using **Decision Tree**.

## Data source
Kaggle: https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data
The dataset was not attached. Data-dependent observations and numerical results must be populated only after actual training.

## Methodology
1. Load original CSV and inspect columns and missingness.
2. Remove identifiers and target leakage; impute missing values; encode categoricals; scale numeric columns.
3. Apply the primary algorithm: **Decision Tree**.
4. Review outputs from `python train_all.py` in `outputs/project_3_metrics.json` and corresponding charts.
5. Interpret outcomes with appropriate caution and limitations.

## Critical thinking answer
A training accuracy of 98% and testing accuracy of 72% suggests overfitting. Restrict depth, increase minimum leaf size and validate by cross-validation. Feature importance is associational, not causal.

## Results
**Pending actual dataset and execution.** Do not report fictional accuracy, confusion matrices or silhouette values. After training, insert real metrics, charts and screenshots here.

## Limitations and ethics
This is an educational prototype, not a clinically validated system. Do not use it to diagnose patients, infer severity or make healthcare decisions. Avoid uploading identifiable patient data.

## Conclusion
The implementation provides a reproducible baseline and interactive visualizations. Findings must be checked against actual experimental outputs before submission.
