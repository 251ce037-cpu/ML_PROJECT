# Project 6: Genetic Patient Similarity Analysis

## Business objective
Build an educational analytics system on the supplied Kaggle genetic-disorder dataset, using **Ward Agglomerative Clustering**.

## Data source
Kaggle: https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data
The dataset was not attached. Data-dependent observations and numerical results must be populated only after actual training.

## Methodology
1. Load original CSV and inspect columns and missingness.
2. Remove identifiers and target leakage; impute missing values; encode categoricals; scale numeric columns.
3. Apply the primary algorithm: **Ward Agglomerative Clustering**.
4. Review outputs from `python train_all.py` in `outputs/project_6_metrics.json` and corresponding charts.
5. Interpret outcomes with appropriate caution and limitations.

## Critical thinking answer
Compare Ward and K-Means on identical standardized features using silhouette and adjusted Rand index. Different geometry and objective functions lead to different groupings.

## Results
**Pending actual dataset and execution.** Do not report fictional accuracy, confusion matrices or silhouette values. After training, insert real metrics, charts and screenshots here.

## Limitations and ethics
This is an educational prototype, not a clinically validated system. Do not use it to diagnose patients, infer severity or make healthcare decisions. Avoid uploading identifiable patient data.

## Conclusion
The implementation provides a reproducible baseline and interactive visualizations. Findings must be checked against actual experimental outputs before submission.
