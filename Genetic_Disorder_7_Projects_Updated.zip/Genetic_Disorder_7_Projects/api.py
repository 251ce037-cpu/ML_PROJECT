from flask import Flask,request,jsonify
from core import predict
from config import OUTPUT
import json
app=Flask(__name__)
@app.get('/health')
def health():return jsonify({'status':'ok'})
@app.get('/metrics/<int:pid>')
def metrics(pid):
    if pid not in range(1,8):return jsonify({'error':'Invalid project'}),404
    path=OUTPUT/f'project_{pid}_metrics.json'
    if not path.exists():return jsonify({'error':'Run training first'}),404
    return jsonify(json.loads(path.read_text()))
@app.post('/predict/<int:pid>')
def prediction(pid):
    if pid not in (1,2,3,4,5):return jsonify({'error':'Prediction not supported for this project'}),400
    body=request.get_json(silent=True)
    if not isinstance(body,dict):return jsonify({'error':'Send JSON object with patient attributes'}),400
    try:return jsonify(predict(pid,body))
    except FileNotFoundError:return jsonify({'error':'Train model first'}),404
    except Exception as e:return jsonify({'error':str(e)}),400
if __name__=='__main__':app.run(host='127.0.0.1',port=5000,debug=False)
